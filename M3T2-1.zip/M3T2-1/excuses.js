function Excuse() {
	
	var randomNames = ['bad', 'lazy', 'stinky'];
	
	var randomAdjectives = ['reviews ','annoying', 'creepy', 'stupid'];
	
	var randomWords = ['games', 'names', 'ads' ];
	
	var who = randomNames[Math.round(Math.random()*(randomNames.length-1))];
	var did = randomAdjectives[Math.round(Math.random()*(randomAdjectives.length-1))];
	var what = randomWords[Math.round(Math.random()*(randomWords.length-1))];
	
	document.getElementById('excuses').innerHTML = '<div>Your app has    ' + who + ' ' + did + '<br>  ' + what + '.</div>'
	
}